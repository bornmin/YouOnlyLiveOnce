// #include <Common.h>
// #include <DBusProxy.h>
// #include <opus.h>
// using namespace std;

// int main()
// {
//     int count = 0;
//     bool b_deinit = false;
//     printf("GDbus Client app start!!!\n");

//     DBusProxy dBusProxy;
//     dBusProxy.init();
//     while (true)
//     {
//         std::cout << "Waiting for calls... (Abort with CTRL+C)$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$" << std::endl;
//         std::this_thread::sleep_for(std::chrono::seconds(5));
//         printf("########## send client -> server\n");
//         dBusProxy.sendMessage("client_ID", "Client_MSG");
//         printf("count: [%d] b_deinit: [%d]\n", count, b_deinit);
//         if (count == 5 && b_deinit == false)
//         {
//             dBusProxy.deinit();
//             b_deinit = true;
//         }
//         else if (count == 8 && b_deinit == true)
//         {
//             dBusProxy.init();
//             b_deinit = false;
//         }
//         else if (count == 11 && b_deinit == false)
//         {
//             dBusProxy.deinit();
//             b_deinit = true;
//         }
//         else if (count == 14 && b_deinit == true)
//         {
//             dBusProxy.init();
//             b_deinit = false;
//         }
//         else if (count == 17 && b_deinit == false)
//         {
//             dBusProxy.deinit();
//             b_deinit = true;
//         }
//         else if (count == 20 && b_deinit == true)
//         {
//             dBusProxy.init();
//             b_deinit = false;
//         }
//         else if (count == 23 && b_deinit == false)
//         {
//             dBusProxy.deinit();
//             b_deinit = true;
//         }
//         else if (count == 27 && b_deinit == true)
//         {
//             dBusProxy.init();
//             b_deinit = false;
//         }
//         count++;
//     }
//     return 0;
// }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// opus example trivial_example.c

/* Copyright (c) 2013 Jean-Marc Valin */
/*
   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
   OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* This is meant to be a simple example of encoding and decoding audio
   using Opus. It should make it easy to understand how the Opus API
   works. For more information, see the full API documentation at:
   http://www.opus-codec.org/docs/ */

// #include <stdlib.h>
// #include <errno.h>
// #include <string.h>
// #include <opus.h>
// #include <stdio.h>
// //#include "opusenc.h"

// /*The frame size is hardcoded for this sample code but it doesn't have to be*/
// #define FRAME_SIZE 960
// #define SAMPLE_RATE 16000
// #define CHANNELS 2
// #define APPLICATION OPUS_APPLICATION_AUDIO
// #define BITRATE 64000

// #define MAX_FRAME_SIZE 6 * 960
// #define MAX_PACKET_SIZE (3 * 1276)

// int main(int argc, char **argv)
// {
//     const char *inFile = "../file/tell_me_the_wether_today_before_encode.pcm";

//     FILE *fin;
//     const char *outdecodingFile = "../file/tell_me_the_wether_today_after_decode.pcm";
//     FILE *fout;
//     const char *outencodingFile = "../file/tell_me_the_wether_today_after_encode.opus";
//     FILE *fencodingOut;
//     opus_int16 in[FRAME_SIZE * CHANNELS];
//     opus_int16 out[MAX_FRAME_SIZE * CHANNELS];
//     unsigned char cbits[MAX_PACKET_SIZE];
//     int nbBytes;
//     /*Holds the state of the encoder and decoder */
//     OpusEncoder *encoder;
//     OpusDecoder *decoder;
//     int err;

//     // if (argc != 3)
//     // {
//     //     fprintf(stderr, "usage: trivial_example input.pcm output.pcm\n");
//     //     fprintf(stderr, "input and output are 16-bit little-endian raw files\n");
//     //     return EXIT_FAILURE;
//     // }

//     /*Create a new encoder state */
//     encoder = opus_encoder_create(SAMPLE_RATE, CHANNELS, APPLICATION, &err);

//     if (err < 0)
//     {
//         fprintf(stderr, "failed to create an encoder: %s\n", opus_strerror(err));
//         return EXIT_FAILURE;
//     }

//     err = opus_encoder_init(encoder, SAMPLE_RATE, CHANNELS, APPLICATION);

//     if (err < 0)
//     {
//         fprintf(stderr, "failed to create an encoder: %s\n", opus_strerror(err));
//         return EXIT_FAILURE;
//     }
//     /* Set the desired bit-rate. You can also set other parameters if needed.
//       The Opus library is designed to have good defaults, so only set
//       parameters you know you need. Doing otherwise is likely to result
//       in worse quality, but better. */
//     err = opus_encoder_ctl(encoder, OPUS_SET_BITRATE(BITRATE));

//     //err = opus_encoder_ctl(encoder, OPUS_SET_BITRATE(BITRATE));
//     if (err < 0)
//     {
//         fprintf(stderr, "failed to set bitrate: %s\n", opus_strerror(err));
//         return EXIT_FAILURE;
//     }
//     fin = fopen(inFile, "r");
//     if (fin == NULL)
//     {
//         fprintf(stderr, "failed to open input file: %s\n", strerror(errno));
//         return EXIT_FAILURE;
//     }

//     /* Create a new decoder state. */
//     decoder = opus_decoder_create(SAMPLE_RATE, CHANNELS, &err);
//     if (err < 0)
//     {
//         fprintf(stderr, "failed to create decoder: %s\n", opus_strerror(err));
//         return EXIT_FAILURE;
//     }
//     fout = fopen(outdecodingFile, "w");
//     if (fout == NULL)
//     {
//         fprintf(stderr, "failed to open output file: %s\n", strerror(errno));
//         return EXIT_FAILURE;
//     }

//     fencodingOut = fopen(outencodingFile, "w");
//     if (fencodingOut == NULL)
//     {
//         fprintf(stderr, "failed to open output file: %s\n", strerror(errno));
//         return EXIT_FAILURE;
//     }

//     while (1)
//     {
//         int i;
//         unsigned char pcm_bytes[MAX_FRAME_SIZE * CHANNELS * 2];
//         int frame_size;

//         /* Read a 16 bits/sample audio frame. */
//         fread(pcm_bytes, sizeof(short) * CHANNELS, FRAME_SIZE, fin);
//         if (feof(fin))
//             break;
//         /* Convert from little-endian ordering. */
//         for (i = 0; i < CHANNELS * FRAME_SIZE; i++)
//             in[i] = pcm_bytes[2 * i + 1] << 8 | pcm_bytes[2 * i];

//         /* Encode the frame. */
//         nbBytes = opus_encode(encoder, in, FRAME_SIZE, cbits, MAX_PACKET_SIZE);
//         if (nbBytes < 0)
//         {
//             fprintf(stderr, "encode failed: %s\n", opus_strerror(nbBytes));
//             return EXIT_FAILURE;
//         }
//         fwrite(cbits, sizeof(short), frame_size * CHANNELS, fencodingOut);
//         /* Decode the data. In this example, frame_size will be constant because
//          the encoder is using a constant frame size. However, that may not
//          be the case for all encoders, so the decoder must always check
//          the frame size returned. */
//         frame_size = opus_decode(decoder, cbits, nbBytes, out, MAX_FRAME_SIZE, 0);
//         if (frame_size < 0)
//         {
//             fprintf(stderr, "decoder failed: %s\n", opus_strerror(frame_size));
//             return EXIT_FAILURE;
//         }

//         /* Convert to little-endian ordering. */
//         for (i = 0; i < CHANNELS * frame_size; i++)
//         {
//             pcm_bytes[2 * i] = out[i] & 0xFF;
//             pcm_bytes[2 * i + 1] = (out[i] >> 8) & 0xFF;
//         }
//         /* Write the decoded audio to file. */
//         fwrite(pcm_bytes, sizeof(short), frame_size * CHANNELS, fout);
//     }
//     /*Destroy the encoder state*/
//     opus_encoder_destroy(encoder);
//     opus_decoder_destroy(decoder);
//     fclose(fin);
//     fclose(fout);
//     fclose(fencodingOut);
//     return EXIT_SUCCESS;
// }

// #include <stdio.h>
// #include <cstdlib>
// #include <fstream>
// #include <vector>
// #include "opusenc.h"

// #define READ_SIZE 960 // fix

// int main(int argc, char **argv)
// {
//     FILE *fin;
//     OggOpusEnc *enc;
//     //OggOpusEnc *enc1;
//     OggOpusComments *comments;
//     int error;
//     //   if (argc != 3) {
//     //     fprintf(stderr, "usage: %s <raw pcm input> <Ogg Opus output>\n", argv[0]);
//     //     return 1;
//     //   }
//     const char *inFile = "../file/tell_me_the_wether_today_before_encode.pcm";
//     const char *outFile = "../file/tell_me_the_wether_today_after_encode.opus";
//     const char *outFile1 = "../file/tell_me_the_wether_today_after_encode1.opus";

//     fin = fopen(inFile, "rb");
//     if (!fin)
//     {
//         fprintf(stderr, "cannot open input file: %s\n", inFile);
//         return 1;
//     }

//     comments = ope_comments_create();
//     // ope_comments_add(comments, "TITLE", "Some track");
//     enc = ope_encoder_create_file(outFile, comments, 8000, 2, 0, &error);
//     ope_encoder_ctl(enc, OPUS_SET_BITRATE(96000));
//     ope_encoder_ctl(enc, OPUS_SET_BANDWIDTH(OPUS_BANDWIDTH_WIDEBAND));
//     ope_encoder_ctl(enc, OPUS_SET_APPLICATION(OPUS_APPLICATION_AUDIO));
//     ope_encoder_ctl(enc, OPUS_SET_EXPERT_FRAME_DURATION(OPUS_FRAMESIZE_60_MS));
//     std::ifstream is("../file/tell_me_the_wether_today_after_encode.opus", std::ios::in | std::ifstream::binary);
//     std::ofstream outfile2(outFile1, std::ios::binary | std::ios::app);
//     //ope_encoder_ctl(enc, OPUS_SET_BITRATE(b));
//     //int err = ope_encoder_flush_header(enc);
//     //int err = ope_encoder_ctl(enc, OPUS_GET_SAMPLE_RATE_REQUEST, 16000);
//     if (!enc)
//     {
//         fprintf(stderr, "error encoding to file %s: %s\n", outFile, ope_strerror(error));
//         ope_comments_destroy(comments);
//         fclose(fin);
//         return 1;
//     }
//     //printf("err: %s", ope_strerror(err));
//     //int ret1 = 0;
//     while (1)
//     {
//         short buf[2 * READ_SIZE];
//         int ret = fread(buf, 2 * sizeof(short), READ_SIZE, fin);
//         //printf("ret1: %d", ret1);
//         if (ret > 0)
//         {
//             ope_encoder_write(enc, buf, ret);
//         }
//         else
//             break;
//     }

//     ope_encoder_drain(enc);
//     ope_encoder_destroy(enc);
//     ope_comments_destroy(comments);
//     fclose(fin);

//     std::vector<unsigned char *> oggData;
//     //oggData.resize(ret);
//     is.seekg(0, is.end);
//     int length = (int)is.tellg();
//     is.seekg(0, is.beg);
//     printf("length: %d", length);
//     unsigned char *buffer = (unsigned char *)malloc(length);

//     is.read((char *)buffer, length);
//     is.close();

//     outfile2.write(reinterpret_cast<const char *>(buffer), length);
//     outfile2.close();
//     is.close();
//     return 0;
// }

// #include <stdio.h>
// #include <cstdlib>
// #include "opusenc.h"
// #include "opus_encode.h"

// opus_enc opus_rec;

// int main(int argc, char **argv)
// {
//     opus_enc_reinit(&opus_rec);
//     opus_enc_write_header(&opus_rec);
//     return 0;
// }
#include <stdio.h>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <string.h>
#include <iostream>
#include <arpa/inet.h>
using namespace std;

int eos_bos = 0;

void setOggHeader(u_int8_t *output){
    int granule_pos=0;
    int headerLen = 0;
    int headerpos = 0;
     memcpy(output + headerLen, "OggS", 4); //OggS
    headerLen += 4;
    headerpos += 3;
    output[headerpos] = 0x00; // version
    headerLen += 1;
    headerpos += 1;
    

    if(eos_bos == 0){  //continue
        eos_bos = 1;
        output[headerpos] = 0x01;
    }else if(eos_bos == 1){ //BOS
        output[headerpos] = 0x02;
    }else if (eos_bos == 2){ // EOS
        output[headerpos] = 0x04;
    }
    headerLen++;
    headerpos++;

    printf("headerpos11: [%d]\n",headerpos - 1);
  for(int i=6;i<14;i++){    // set Granule Position
    output[i]=(unsigned char)(granule_pos&0xff);
    std::cout << "granule_pos1: "<<headerLen << std::endl; 
    granule_pos>>=8;    
    std::cout << "granule_pos2: " << headerLen << std::endl;
    headerLen++;
    headerpos++;
  }
    printf("headerpos22: [%d]\n",headerpos -1);
  for(int i =0; i< headerpos; i++){
      std::cout << "output:  [" << i << "]: "<< output[i] << std::endl;
   }
  for(int i=14;i<18;i++){
      output[i]=(unsigned char)(granule_pos&0xff);
      granule_pos>>=8;
      headerLen++;
        headerpos++;
    }
    for(int i =0; i< headerpos; i++){
      std::cout << "output:  [" << i << "]: "<< output[i] << std::endl;
   }
    printf("headerpos33: [%d]\n",headerpos - 1);
    unsigned int number2 = htonl(3);
    memcpy(output+headerpos, &number2, 4);
    headerpos+=4;
    headerLen+=4;
    for(int i =0; i< headerpos; i++){
      std::cout << "output:  [" << i << "]: "<< output[i] << std::endl;
   }
   printf("headerpos44: [%d]\n",headerpos - 1);
    

    memset(output + 5, 0x00, 1);
    headerLen += 1;
    memset(output + 6, 0x00, 8);
    headerLen += 8;
    memset(output + 14, 0x00, 4);
    headerLen += 4;
    memset(output + 18, 0x00, 4);
    headerLen += 4;
    memset(output + 22, 0x00, 4);
    headerLen += 4;
    memset(output + 26, 0x00, 1);
    headerLen += 1;
}

int main(){

    u_int8_t headerData[1000];

    setOggHeader(headerData);

    return 0;
}

