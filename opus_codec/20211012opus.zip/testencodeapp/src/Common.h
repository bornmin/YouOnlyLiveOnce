#include <iostream>
#include <thread>
#include <string>
#include <unistd.h>
#include <glibmm.h>
#include <glib.h>
using namespace std;

#define VRTTSIPC_DBUS_PATH "/ccos/core/vrttsipc"
#define VRTTSIPC_DBUS_INTERFACE "ccos.core.vrttsipc"
