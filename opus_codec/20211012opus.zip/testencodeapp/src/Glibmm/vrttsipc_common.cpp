#include "./vrttsipc_common.h"

#include <cstring>

